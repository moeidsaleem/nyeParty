app.controller('adminCtrl', function ($scope,$firebaseAuth,$firebaseObject,$firebaseArray) {
         
         let users = firebase.database().ref().child('users');
       $scope.userArr = $firebaseArray(users);


       $scope.storagePath = "gs://one-link-921d7.appspot.com";
       $scope.userInput = 'user1';
       const db   = firebase.database().ref();
       const vcard = db.child('users').child(0).child('vcard');

       const storageRef = firebase.storage().ref();
       var imageRef = storageRef.child('ain.jpg');
       $scope.st = imageRef;      
        $scope.x= $firebaseObject(vcard);


     // $scope.data = [
	    //    {name:"ain un haq",
	    //     email:"ainunhaq@hotmail.com",
	    //     companyName:"OneLink",
	    //     designation:"FOUNDER OneLink",
	    //     phone:"03315492778",
	    //     uid:2323232323232131,
	    //     qr:{
	    //     	version:6,
	    //     	level:'H',
	    //     	href:'http://atrixdigital.com',
	    //     	size:170
	    //     }

	    //     }]; 
	    //     JSON.Stringify($scope.data);
	    //     console.log(x);  

    $scope.auth = $firebaseAuth();
   $scope.authRun = function(){

	auth.signInWithEmailAndPassword($scope.email , $scope.password).then(function(firebaseUser){
		console.log("Signed in as:", firebaseUser.uid);
		}).catch(function(error) {
		console.error("Authentication failed:", error);
});
}
});